package com.notification.generate;

/*
 * 邮件生成接口
 */
public interface IGenerate {
	public void scan();
}
