package com.notification.entity.mail;

/*
 * 邮件发送接口
 */
public interface IMail {
	public void send();
}
